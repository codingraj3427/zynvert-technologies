// src/pages/Admin/AdminProductsPage.jsx
import React, { useEffect, useState } from "react";
import { adminService } from "../../services/admin.service";
import "./AdminProducts.css";

const defaultForm = {
  product_id: "",
  sku: "",
  stock_level: "",
  current_price: "",
  category_id: "",
  name: "",
  description: "",
  imagesText: "",
  technical_specs_text: "",
  isFeatured: false,
  showOnHome: false,
};

const AdminProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState(defaultForm);
  const [submitting, setSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);

  // ===== Load products =====
  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true);
        setError("");

        const data = await adminService.getProducts();
        const list = Array.isArray(data)
          ? data
          : Array.isArray(data?.products)
          ? data.products
          : [];
        setProducts(list);
      } catch (err) {
        console.error("Failed to load products:", err);
        setError("Failed to load products");
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

 const buildPayloadFromForm = () => {
  const productId =
    (form.product_id && String(form.product_id).trim()) ||
    `prod_${Date.now()}`;

  const name = form.name.trim();
  const categoryId = form.category_id.trim();
  const description = form.description.trim();

  // images → array of strings, non-empty
  const images = form.imagesText
    .split(/[\n,]/)
    .map((s) => s.trim())
    .filter(Boolean);

  const technical_specs = form.technical_specs_text
    ? { description: form.technical_specs_text }
    : undefined;

  const display_flags = [
    ...(form.isFeatured ? ["featured"] : []),
    ...(form.showOnHome ? ["home"] : []),
  ];

  return {
    product_id: productId,
    sku: form.sku || null,
    stock_level: Number(form.stock_level),
    current_price: Number(form.current_price),
    category_id: categoryId,
    name,
    description,
    images,
    technical_specs,
    display_flags,
  };
};



  const handleCreate = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");

    try {
      const payload = buildPayloadFromForm();
      const created = await adminService.createProduct(payload);

      console.log("Created product response:", created);

      setForm(defaultForm);
      setShowForm(false);

      // Reload products from server
      try {
        const data = await adminService.getProducts();
        const list = Array.isArray(data)
          ? data
          : Array.isArray(data?.products)
          ? data.products
          : [];
        setProducts(list);
      } catch (reloadErr) {
        console.error("Failed to reload products:", reloadErr);
      }
    } catch (err) {
      console.error("Failed to create product:", err);
      // If backend sends { message, error }, show that
      const msg =
        err?.response?.data?.message ||
        err?.message ||
        "Failed to create product";
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  };

const handleDelete = async (product) => {
  const id = product.product_id || product.id || product._id;
  if (!id) return;
  if (!window.confirm("Delete this product?")) return;

  await adminService.deleteProduct(id);
  setProducts((prev) =>
    prev.filter(
      (p) => p.product_id !== id && p.id !== id && p._id !== id
    )
  );
};

  return (
    <div className="admin-page">
      <div className="admin-page-header">
        <h1>Products</h1>
        <button
          className="admin-btn primary"
          onClick={() => setShowForm((v) => !v)}
        >
          {showForm ? "Close" : "Add Product"}
        </button>
      </div>

      {error && (
        <p style={{ color: "red", marginBottom: "1rem" }}>{error}</p>
      )}

      {showForm && (
        <form
          className="admin-card admin-product-form"
          onSubmit={handleCreate}
        >
          <div className="form-row">
            <label>
              Product ID
              <input
                name="product_id"
                value={form.product_id}
                onChange={handleChange}
                placeholder="If empty, will be auto-generated"
              />
            </label>
            <label>
              SKU
              <input
                name="sku"
                value={form.sku}
                onChange={handleChange}
                placeholder="e.g. ZYN-100AH"
              />
            </label>
          </div>

          <div className="form-row">
            <label>
              Current Price (₹) *
              <input
                type="number"
                name="current_price"
                value={form.current_price}
                onChange={handleChange}
                required
                min="0"
              />
            </label>
            <label>
              Stock Level *
              <input
                type="number"
                name="stock_level"
                value={form.stock_level}
                onChange={handleChange}
                required
                min="0"
              />
            </label>
          </div>

          <div className="form-row">
            <label>
              Category ID
              <input
                name="category_id"
                value={form.category_id}
                onChange={handleChange}
                placeholder="e.g. cat_lifepo4"
                required
              />
            </label>
            <label>
              Name *
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                required
              />
            </label>
          </div>

          <label>
            Description
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              rows={3}
              required
            />
          </label>

          <label>
            Images (one URL per line or comma-separated)
            <textarea
              name="imagesText"
              value={form.imagesText}
              onChange={handleChange}
              rows={3}
              placeholder={"https://...\nhttps://..."}
            />
          </label>

          <label>
            Technical Specs (free text / JSON)
            <textarea
              name="technical_specs_text"
              value={form.technical_specs_text}
              onChange={handleChange}
              rows={3}
              placeholder='e.g. "12V 100Ah LiFePO4, 3000 cycles"'
            />
          </label>

          <div className="form-row">
            <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input
                type="checkbox"
                name="isFeatured"
                checked={form.isFeatured}
                onChange={handleChange}
              />
              Featured
            </label>
            <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input
                type="checkbox"
                name="showOnHome"
                checked={form.showOnHome}
                onChange={handleChange}
              />
              Show on Home
            </label>
          </div>

          <button
            type="submit"
            className="admin-btn primary"
            disabled={submitting}
          >
            {submitting ? "Saving..." : "Save Product"}
          </button>
        </form>
      )}

      <div className="admin-card">
        {loading ? (
          <p>Loading products…</p>
        ) : products.length === 0 ? (
          <p>No products yet. Click “Add Product” to create one.</p>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>Product ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Display Price</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.product_id || p._id}>
                  <td>{p.product_id}</td>
                  <td>{p.name}</td>
                  <td>{p.category_id || "-"}</td>
                  <td>{p.price_display ?? "-"}</td>
                  <td>
                    <button
                      className="admin-btn danger"
                      onClick={() => handleDelete(p)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default AdminProductsPage;
